class Gempa:
    #Konstruktor Inisialisasi atribut lokasi skala
    def __init__(self,lokasi,skala):

       # Atribut 
       self.lokasi=lokasi
       self.skala=skala
    
    #method menentukan dampak skala gempa
    def dampak(self):

        # Statement / logika 
        if self.skala < 2 :
            print('Dampak Gempa Tidak Berasa')
        elif self.skala >=2 and self.skala <=4:
            print('Dampak Gempa Bangunan Retak-retak')
        elif self.skala > 4 and self.skala <= 6:
            print('Dampak Gempa Berdampak bangunan roboh')
        elif self.skala > 6:
            print('Dampak Gempa Berpotensi Tsunami')

        #Menampilkan Lokasi dan skala 
        print(f'Lokasi gempa:{self.lokasi}')
        print(f'Skala gempa:{self.skala}')
