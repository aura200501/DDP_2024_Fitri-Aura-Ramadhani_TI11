from Animal import Animal

class Ular (Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, berbisa, bentuk_kepala):
        super().__init__ (name, makanan, hidup, berkembang_biak)
        self.berbisa = berbisa
        self.bentuk_kepala = bentuk_kepala

    def info_ular(self):
        super().info_animal()
        print("Memiliki Bisa\t\t:", self.berbisa,
              "\nBentuk Kepalanya\t:", self.bentuk_kepala)
        
#Objek
print()
ular = Ular("Cobra", "Tikus", "Hutan hujan tropis", "Bertelur", "Berbisa" ,"Segitiga")
print("======================================")
print("## Info Ular##")
ular.info_ular()

print()
ular = Ular("Sanca", "Tikus", "Hutan hujan tropis", "Bertelur", "Tidak Berbisa", "Bulatan")
print("======================================")
print("## Info Ular ##")
ular.info_ular()

print()
ular = Ular("Python", "Kelinci", "Hutan hujan tropis", "Bertelur", "Tidak Berbisa", "Segitiga")
print("======================================")
print("## Info Ular ##")
ular.info_ular()

print()
ular = Ular("Anaconda", "Ikan", "Sungai", "Bertelur", "Tidak Berbisa", "Segitiga")
print("======================================")
print("## Info Ular ##")
ular.info_ular() 
