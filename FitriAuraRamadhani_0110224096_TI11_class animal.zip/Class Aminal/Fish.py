from Animal import Animal

class Fish(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, bernafas, habitat):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.bernafas = bernafas
        self.habitat = habitat

    def info_fish(self):
        super().info_animal()
        print("Bernafas menggunakan\t:", self.bernafas,
              "\nHabitat Di\t\t:", self.habitat)
        
#Objek
print()
fish = Fish("Hiu", "Daging", "laut", "Bertelur dan Melahirkan", "Insang", "Air Asin")
print("======================================")
print("## Info Fish ##")
fish.info_fish()

print()
fish = Fish("Pau Biru", "Ikan", "Laut", "Melahirkan", "Paru-paru", "Air Tawar")
print("======================================")
print("## Info Fish ##")
fish.info_fish()

print()
fish = Fish("Ikan Badut", "Zooplankton", "Laut", "Bertelur", "Insang", "Terumbu Karang")
print("======================================")
print("## Info Fish ##")
fish.info_fish()

print()
fish = Fish("Lumba-lumba", "Ikan", "Laut", "Melahirkan", "Paru-paru", "Air Asin dan Tawar")
print("======================================")
print("## Info Fish ##")
fish.info_fish()


