from Animal import Animal

class Bird(Animal):
    #Konstruktor properti
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna, paruh):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna = warna
        self.paruh = paruh

    # Method Info
    def info_bird(self):
        super().info_animal()
        print("Warna\t\t\t:",self.warna,
              "\nJenis Paruh\t\t:",self.paruh)
        
bird = Bird ("Elang", "Daging", "Ditebing","Menghasilkan Telur", "Coklat", "Bengkok dan Lancip")
print("================================================")
print("## Info Bird ##")
bird.info_bird()

bird = Bird ("Pinguin", "Ikan", "Di Antartika","Bertelur", "Hitam Putih/Abu-abu Putih", "Panjang dan Lancip")
print("================================================")
print("## Info Bird ##")
bird.info_bird()

bird = Bird ("Burung Unta", "Rumput, daun, buah-buahan, biji-bijian, dan akar", "Di Gurun","Bertelur", "Coklat keabu-abuan putih", "tidak bergerigi dan lancip")
print("================================================")
print("## Info Bird ##")
bird.info_bird()

bird = Bird ("Burung Beo", "Buah-buahan, Biji-bijian dan Serangga ", "Dataran Tinggi","Bertelur", "Campuran warna merah, kuning, biru, dan orange", "Melengkung")
print("================================================")
print("## Info Bird ##")
bird.info_bird()




        